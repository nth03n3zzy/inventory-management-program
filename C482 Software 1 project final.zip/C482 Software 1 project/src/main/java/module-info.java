module com.example.c482software1project {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.c482software1project to javafx.fxml;
    exports com.example.c482software1project;
}